# Text Editor

A Pen created on CodePen.io. Original URL: [https://codepen.io/nDav/pen/rOOwxG](https://codepen.io/nDav/pen/rOOwxG).

A simple text editor made using jQuery, spectrum.js (for color picker) and perfect-scrollbar.js